#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <vector>
#include <math.h>
	


using std::FILE;
using std::string;
using std::cout;
using std::endl;
using std::cerr;
using std::ifstream;
using std::stringstream;
using std::map;
using std::vector;

map<int,vector<int>> setLRU1(map<int,vector<int>> LRU, unsigned long int set , int way) ;  	
int getLRU1(map<int,vector<int>> LRU , unsigned long int  set);
void printLRU(map<int,vector<int>> LRU ) ;

class cacheLine{
public:
    bool valid;
    bool dirty;
    unsigned long int tag;
    unsigned long int real_addr;
    cacheLine(): valid(false), dirty(false), tag(0),real_addr(0){}
    explicit cacheLine(unsigned long int tag,unsigned long int real_addr) : valid(true), dirty(false), tag(tag),real_addr(real_addr){}

};

void printWays(map<int,map<int,cacheLine>> ways) ;

class cacheLevel {
public:
	map<int,map<int,cacheLine>> ways;
	int numOfWays;
	int numOfLinesInWay;
	double missCount;
	double numAccess;
	unsigned BSize;
	map<int,vector<int>> LRU;
	cacheLevel() : numOfWays(0),numOfLinesInWay(0),missCount(0),numAccess(0){}
	cacheLevel(unsigned BSize ,unsigned LSize ,unsigned LAssoc): BSize(BSize),missCount(0),numAccess(0) {
		numOfWays = pow(2,LAssoc);
		numOfLinesInWay = pow(2,LSize-BSize-LAssoc);
		for(int i = 0 ; i < numOfWays ; i++) {
			for(int j = 0 ; j < numOfLinesInWay; j++ ) {
				ways[i][j].tag = 0;
				ways[i][j].real_addr = 0;
				ways[i][j].valid = 0;
				ways[i][j].dirty = 0;
			}
		}
		
		for(int i = 0; i < numOfLinesInWay ; i++) {
			for(int j = 0 ; j < numOfWays ; j++) {
				LRU[i].push_back(j);
			}
		}
			
	}
	
	
	unsigned long int Set(unsigned long int pc) {
		return (pc / (unsigned long)pow(2,BSize)) % numOfLinesInWay;
	}
	unsigned long int Tag(unsigned long int pc) {
		return pc /	(unsigned long)pow(2,BSize) / numOfLinesInWay;
	}
	int existInLevel(unsigned long int pc ) {
		unsigned long currentSet = Set(pc);
		for(int i = 0 ; i < numOfWays ; i++) {
			if(ways[i][currentSet].valid && ways[i][currentSet].tag == Tag(pc)) {
				return i;
			}
		}
		return -1;
	}
	int emptyPlace(unsigned long int pc) {
		unsigned long currentSet = Set(pc);
		for(int i = 0 ; i < numOfWays ; i++) {
			if (!(ways[i][currentSet].valid )) {
				return i;
			}
		}
		return -1;
	}
	
};



class cache {
public:
	cacheLevel L1;
	cacheLevel L2;
	unsigned BSize ;
	unsigned L1Size ;
	unsigned L2Size;
	unsigned L1Assoc;
	unsigned L2Assoc ; 
	unsigned WrAlloc ;  // if 0 no write allocate, if 1 write allocate
	unsigned memAccess ;
	
	cache(unsigned BSize ,unsigned L1Size ,unsigned L2Size,unsigned L1Assoc,unsigned L2Assoc , unsigned WrAlloc  ): BSize(BSize) ,
		L1Size(L1Size),L2Size(L2Size),L1Assoc(L1Assoc), L2Assoc(L2Assoc), WrAlloc(WrAlloc) , memAccess(0){
			
			L1 = cacheLevel(BSize , L1Size, L1Assoc);
			L2 = cacheLevel(BSize , L2Size, L2Assoc);
	}
	
	map<int,vector<int>> setLRU(map<int,vector<int>> LRU, unsigned long int set , int way) {
		vector<int>::iterator it ;
		int currWay;
		for(it = LRU[set].begin() ; it != LRU[set].end() ; it++ ) {
			currWay = *it;
			if (*it == way ) {
				LRU[set].erase(it);
				LRU[set].push_back(currWay);
			}
		}
		return LRU;
	}

	int getLRU(map<int,vector<int>> LRU , unsigned long int  set){
		return LRU[set].front();
	}

	void read(unsigned long int pc) {
        L1.numAccess++;
        unsigned long int set1 = L1.Set(pc);
        unsigned long int tag1 = L1.Tag(pc);
        unsigned long int set2 = L2.Set(pc);
        unsigned long int tag2 = L2.Tag(pc);

		if( L1.existInLevel(pc) != -1 ) {  /// L1 Hit
            L1.LRU = setLRU(L1.LRU,set1,L1.existInLevel(pc));
            return;
        }
        //////////// L1 Miss
        L1.missCount++;
        L2.numAccess++;

        if( L2.existInLevel(pc) != -1) { // L2 Hit
            L2.LRU = setLRU(L2.LRU,set2,L2.existInLevel(pc));
        } else {  //////// L2 Miss
            L2.missCount++;
            memAccess++;
            if(L2.emptyPlace(pc) != -1) { /////// Empty Place In L2
                L2.ways[L2.emptyPlace(pc)][set2] = cacheLine(tag2,pc);
                L2.LRU = setLRU(L2.LRU,set2,L2.emptyPlace(pc));
            }else { //////// L2 is Full

                int L2LRU = getLRU(L2.LRU,set2);
                cacheLine removed2 = L2.ways[L2LRU][set2];
                int existInL1 = L1.existInLevel(removed2.real_addr);
                if(existInL1 != -1 ) { /// also exists in L1
                    L1.ways[existInL1][L1.Set(removed2.real_addr)].valid = false;
                    L1.LRU = setLRU(L1.LRU,L1.Set(removed2.real_addr),existInL1);
                }
                L2.ways[L2LRU][set2] = cacheLine(tag2,pc);
                L2.LRU = setLRU(L2.LRU,set2,L2LRU);
            }
        }
        if(L1.emptyPlace(pc) != -1 ) { /// Empty Place in L1
            L1.ways[L1.emptyPlace(pc)][set1] = cacheLine(tag1,pc);

            L1.LRU = setLRU(L1.LRU,set1,L1.emptyPlace(pc));
        } else { /// L1 is Full
            int L1LRU = getLRU(L1.LRU,set1);
            cacheLine removed1 = L1.ways[L1LRU][set1];

            if (removed1.dirty && removed1.valid) {
                int removedExistInL2 =  L2.existInLevel(removed1.real_addr);
                L2.ways[removedExistInL2][L2.Set(removed1.real_addr)].dirty = true;
                L2.LRU = setLRU(L2.LRU,L2.Set(removed1.real_addr),removedExistInL2);
            }
            L1.ways[L1LRU][set1] = cacheLine(tag1,pc);
            L1.LRU = setLRU(L1.LRU,set1,L1LRU);
        }
	}


	void write(unsigned long int pc) {
        L1.numAccess++;
        unsigned long int set1 = L1.Set(pc);
        unsigned long int tag1 = L1.Tag(pc);
        unsigned long int set2 = L2.Set(pc);
        unsigned long int tag2 = L2.Tag(pc);

		if( L1.existInLevel(pc) != -1 ) {  /// L1 Hit
            L1.LRU = setLRU(L1.LRU,set1,L1.existInLevel(pc));
            L1.ways[L1.existInLevel(pc)][set1].dirty =true;
            return;
        }
        //////////// L1 Miss
        L1.missCount++;
        L2.numAccess++;
        if( L2.existInLevel(pc) != -1) { // L2 Hit
            L2.LRU = setLRU(L2.LRU,set2,L2.existInLevel(pc));
            if (!WrAlloc) {
                L2.ways[L2.existInLevel(pc)][set2].dirty = true;
            }
        } else {  //////// L2 Miss
            L2.missCount++;
            memAccess++;
			int emptyPlaceInL2 = L2.emptyPlace(pc);
            if(emptyPlaceInL2 != -1) { /////// Empty Place In L2
                if(WrAlloc) {
                    L2.ways[emptyPlaceInL2][set2] = cacheLine(tag2,pc);
					L2.ways[emptyPlaceInL2][set2].dirty = true;
                    L2.LRU = setLRU(L2.LRU,set2,emptyPlaceInL2);
                }
            } else { //////// L2 is Full
                if(WrAlloc){
                    int L2LRU = getLRU(L2.LRU,set2);
                    cacheLine removed2 = L2.ways[L2LRU][set2];
                    int existInL1 = L1.existInLevel(removed2.real_addr);
                    if(existInL1 != -1 ) { /// also exists in L1
                        L1.ways[existInL1][L1.Set(removed2.real_addr)].valid = false;
                        L1.LRU = setLRU(L1.LRU,L1.Set(removed2.real_addr),existInL1);
                    }
                    L2.ways[L2LRU][set2] = cacheLine(tag2,pc);
					L2.ways[L2LRU][set2].dirty = true;
                    L2.LRU = setLRU(L2.LRU,set2,L2LRU);
                }
            }
        }
		int emptyPlaceInL1 = L1.emptyPlace(pc);
        if(emptyPlaceInL1 != -1 ) { /// Empty Place in L1
            if(WrAlloc){
                L1.ways[emptyPlaceInL1][set1] = cacheLine(tag1,pc);
				L1.ways[emptyPlaceInL1][set1].dirty = true;
                L1.LRU = setLRU(L1.LRU,set1,emptyPlaceInL1);
            }
        } else { /// L1 is Full
            if(WrAlloc) {
                int L1LRU = getLRU(L1.LRU,set1);
                cacheLine removed1 = L1.ways[L1LRU][set1];
                if (removed1.dirty && removed1.valid) {
                    int removedExistInL2 =  L2.existInLevel(removed1.real_addr);
                    L2.ways[removedExistInL2][L2.Set(removed1.real_addr)].dirty = true;
                    L2.LRU = setLRU(L2.LRU,L2.Set(removed1.real_addr),removedExistInL2);
                }
                L1.ways[L1LRU][set1] = cacheLine(tag1,pc);
                L1.ways[L1LRU][set1].dirty = true;
                L1.LRU = setLRU(L1.LRU,set1,L1LRU);
            }
        }
    }
	
};



int main(int argc, char **argv) {
	if (argc < 19) {
		cerr << "Not enough arguments" << endl;
		return 0;
	}

	// Get input arguments

	// File
	// Assuming it is the first argument
	char* fileString = argv[1];
	ifstream file(fileString); //input file stream
	string line;
	if (!file || !file.good()) {
		// File doesn't exist or some other error
		cerr << "File not found" << endl;
		return 0;
	}

	unsigned MemCyc = 0, BSize = 0, L1Size = 0, L2Size = 0, L1Assoc = 0,
			L2Assoc = 0, L1Cyc = 0, L2Cyc = 0, WrAlloc = 0;

	for (int i = 2; i < 19; i += 2) {
		string s(argv[i]);
		if (s == "--mem-cyc") {
			MemCyc = atoi(argv[i + 1]);
		} else if (s == "--bsize") {
			BSize = atoi(argv[i + 1]);
		} else if (s == "--l1-size") {
			L1Size = atoi(argv[i + 1]);
		} else if (s == "--l2-size") {
			L2Size = atoi(argv[i + 1]);
		} else if (s == "--l1-cyc") {
			L1Cyc = atoi(argv[i + 1]);
		} else if (s == "--l2-cyc") {
			L2Cyc = atoi(argv[i + 1]);
		} else if (s == "--l1-assoc") {
			L1Assoc = atoi(argv[i + 1]);
		} else if (s == "--l2-assoc") {
			L2Assoc = atoi(argv[i + 1]);
		} else if (s == "--wr-alloc") {
			WrAlloc = atoi(argv[i + 1]);
		} else {
			cerr << "Error in arguments" << endl;
			return 0;
		}
	}

    cache c = cache(BSize,L1Size,L2Size,L1Assoc,L2Assoc,WrAlloc);
	while (getline(file, line)) {

		stringstream ss(line);
		string address;
		char operation = 0; // read (R) or write (W)
		if (!(ss >> operation >> address)) {
			// Operation appears in an Invalid format
			//cout << "Command Format error" << endl;
			return 0;
		}

		// DEBUG - remove this line
		//cout << "operation: " << operation;

		string cutAddress = address.substr(2); // Removing the "0x" part of the address

		// DEBUG - remove this line
		//cout << ", address (hex)" << cutAddress;

		unsigned long int num = 0;
		num = strtoul(cutAddress.c_str(), NULL, 16);

		// DEBUG - remove this line
		//cout << " (dec) " << num << endl;
        if(operation=='w'){
            c.write(num);
        }
        if(operation=='r'){
            c.read(num);
        }

	}

    double L1MissRate = c.L1.missCount / c.L1.numAccess;
    double L2MissRate = c.L2.missCount / c.L2.numAccess;
    double avgAccTime = ((c.L1.numAccess * L1Cyc) + (c.L2.numAccess * L2Cyc) + (c.memAccess* MemCyc)) / c.L1.numAccess;
	printf("L1miss=%.03f ", L1MissRate);
	printf("L2miss=%.03f ", L2MissRate);
	printf("AccTimeAvg=%.03f\n", avgAccTime);

	return 0;
}

//
void printLRU(map<int,vector<int>> LRU ) {
    cout << "printing LRU" <<endl;
	map<int,vector<int>>::iterator it;
	vector<int>::iterator way_it;
	for(it = LRU.begin() ; it != LRU.end() ; it++) {
		cout << "set " << it->first <<": ";
		for(way_it = it->second.begin() ; way_it != it->second.end() ; way_it++) {
			cout << *way_it << ", ";
		}
		cout << endl;
	}
}
void printWays(map<int,map<int,cacheLine>> ways) {
    map<int,map<int,cacheLine>>::iterator it ;
    map<int,cacheLine>::iterator set_it;
    for(it = ways.begin() ; it != ways.end() ; it++) {
        cout << "way: " << it->first << endl;
        for(set_it = it->second.begin() ; set_it != it->second.end() ; set_it++) {
            cout << "set: " << set_it->first << ", tag: " << set_it->second.tag <<
             ", valid: "  << set_it->second.valid << ", dirty: " << set_it->second.dirty <<endl;
        }
        cout << endl;
    }
}